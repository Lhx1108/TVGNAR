#include <RcppEigen.h>
using namespace Rcpp;
using namespace Eigen;

// [[Rcpp::depends(RcppEigen)]]

// [[Rcpp::export]]
VectorXd least_squares_svd_eig(const MatrixXd &A, const VectorXd &b)
{

  // Eigen::setNbThreads(24);
  Eigen::VectorXd x = A.bdcSvd(Eigen::ComputeThinU | Eigen::ComputeThinV).solve(b);

  return x;
}

// [[Rcpp::export]]
VectorXd least_squares_direct_eig(const MatrixXd &A, const VectorXd &b)
{

  // Eigen::setNbThreads(24);
  MatrixXd A_T_A = A.transpose() * A;

  VectorXd A_T_b = A.transpose() * b;

  VectorXd x = A_T_A.partialPivLu().solve(A_T_b);

  return x;
}

// [[Rcpp::export]]
VectorXd least_squares_qr_eig(const MatrixXd &A, const VectorXd &b)
{

  MatrixXd A_T_A = A.transpose() * A;
  
  VectorXd A_T_b = A.transpose() * b;
  
  VectorXd x = A_T_A.colPivHouseholderQr().solve(A_T_b);
  
  return x;
}
