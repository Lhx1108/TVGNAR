RemoveFrom <- function(l, xs) {
  for (x in xs) {
    if (x %in% l) {
      l <- l[l != x]
    } else {
      stop(x)
    }
  }
  return(l)
}

Network <- setRefClass(
  "Network",
  fields = list(
    nodes = "list",
    size = "numeric",
    edges = "list",
    dists = "list",
    neighbours_dict = "list",  # renamed from neighbours
    neighbour_weights_dict = "list",  # renamed from neighbour_weights
    adj_mat = "matrix",
    w_mats = "list",
    num_edges = "numeric"
  ),
  
  methods = list(
    initialize = function(edges = NULL, dists = NULL, GNAR_net = NULL, symmetry = FALSE) {
      #edges are incoming here
      if(!is.null(GNAR_net)){
        edges = GNAR_net$edges
        dists = GNAR_net$dist
      }
      if(!is.null(edges)){
        if(is.null(names(edges))){
          names(edges) = as.character(seq_along(edges))
        }
        .self$nodes <- as.list(names(edges))
        .self$size <- length(.self$nodes)
        .self$edges <- edges
        .self$num_edges = length(unlist(.self$edges))
        
        if (symmetry) {
          for (key in names(.self$edges)) {
            for (node in .self$edges[[key]]) {
              if (!(key %in% .self$edges[[as.character(node)]])) {
                .self$edges[[as.character(node)]] <- c(.self$edges[[as.character(node)]], key)
              }
            }
          }
        }
        
        if (!is.null(dists)) {
          if(is.null(names(dists))){
            names(dists) = as.character(seq_along(dists))
          }
          .self$dists <- dists
        } else {
          .self$dists <- lapply(edges, function(value) rep(1, length(value)))
        }
        
        .self$neighbours_dict <- list()  # updated name
        .self$neighbour_weights_dict <- list()  # updated name
        for (key in names(edges)) {
          neighbours_weights = .self$ComputeNeighbours(as.numeric(key))
          .self$neighbours_dict[[key]] <- neighbours_weights[[1]]  # updated name
          .self$neighbour_weights_dict[[key]] <- neighbours_weights[[2]]  # updated name
        }
        
        .self$adj_mat <- .self$AdjMatrix()
        .self$w_mats <- .self$WeightMatrix()
      }
    },
    
    AdjMatrix = function() {
      mat <- matrix(0, nrow = .self$size, ncol = .self$size)
      for (i in seq_len(.self$size)) {
        mat[.self$edges[[as.character(i)]],i] <- 1
      }
      return(mat)
    },
    
    ComputeNeighbours = function(node) {
      neighbours <- list(.self$edges[[as.character(node)]])
      neighbour_weights <- list(1 / .self$dists[[as.character(node)]] / sum(1 / .self$dists[[as.character(node)]]))
      nodes_left <- .self$nodes
      nodes_left <- RemoveFrom(nodes_left, c(neighbours[[1]], node))
      prev_dists <- .self$dists[[as.character(node)]]
      
      while (TRUE) {
        stage_neighbours <- c()
        stage_dists <- list()
        
        for (i in 1:length(neighbours[[length(neighbours)]])) {
          prev_neighbour = neighbours[[length(neighbours)]][i]
          for (j in 1:length(.self$edges[[as.character(prev_neighbour)]])) {
            stage_neighbour = .self$edges[[as.character(prev_neighbour)]][j]
            if ((stage_neighbour %in% nodes_left) && stage_neighbour != node) {
              if (!(stage_neighbour %in% stage_neighbours)) {
                stage_neighbours <- c(stage_neighbours, stage_neighbour)
                stage_dists[[as.character(stage_neighbour)]] <- prev_dists[i] + .self$dists[[as.character(prev_neighbour)]][j]
              } else {
                stage_dists[[as.character(stage_neighbour)]] <- c(stage_dists[[as.character(stage_neighbour)]], prev_dists[i] + .self$dists[[as.character(prev_neighbour)]][j])
              }
            }
          }
        }
        
        if (length(stage_neighbours) == 0) {
          return(list(neighbours, neighbour_weights))
        }
        
        stage_dists <- sapply(stage_dists, min)
        nodes_left <- RemoveFrom(nodes_left, stage_neighbours)
        neighbours <- append(neighbours, list(stage_neighbours))
        neighbour_weights <- append(neighbour_weights, list(1 / stage_dists / sum(1 / stage_dists)))
        prev_dists <- stage_dists
      }
    },
    
    WeightMatrix = function() {
      max_stage <- max(sapply(.self$neighbours_dict, length))  
      mats <- list(diag(.self$size))
      
      for (r in seq_len(max_stage)) {
        mat <- matrix(0, nrow = .self$size, ncol = .self$size)
        for (i in seq_len(.self$size)) {
          if (length(.self$neighbours_dict[[as.character(i)]]) >= r) {  
            mat[.self$neighbours_dict[[as.character(i)]][[r]],i] <- .self$neighbour_weights_dict[[as.character(i)]][[r]]  
          }
        }
        #mats[[r + 1]] <- sweep(mat, 2, colSums(mat), "/")
        mats[[r + 1]] <- mat
        #mats[[r + 1]][is.na(mats[[r + 1]])] <- 0
      }
      return(mats)
    },
    
    show = function(){
      if(!is.null(.self$edges)){
        cat("Network with ", as.character(.self$size), " nodes.\n", sep="")
        display = "Edges:"
        count = 0
        for(i in 1:.self$size){
          for(j in .self$edges[[as.character(i)]]){
            if(count>20){
              break
            }
            display = paste(display, " ", as.character(j), "->", as.character(i), " ",sep="")
            count = count+1
          }
          if(count>20){
            display = paste(display, " ...", sep="")
            break
          }
        }
        cat(display)
      }
    },
    
    summary = function(){
      cat("Network with ", as.character(.self$size), " nodes and ",
                as.character(.self$num_edges), " edges.",sep = "")
    }
  )
)

tridiagonal_network <- function(N) {
  edges <- list()
  
  # Define edges for node 1 (connected to node 2 and node N)
  edges[["1"]] <- c(2, N)
  
  # Define edges for node N (connected to node N-1 and node 1)
  edges[[as.character(N)]] <- c(N-1, 1)
  
  # Define edges for nodes 2 to N-1
  for (i in 2:(N-1)) {
    edges[[as.character(i)]] <- c(i-1, i+1)
  }
  
  # Return the Network object with edges
  return(Network$new(edges = edges))
}

random_network <- function(N,l_ratio=0.25,u_ratio=0.75) {
  edges <- list()
  indices <- 1:N
  
  for (i in 1:N) {
    indices <- setdiff(indices, i)  # Remove i from indices
    num_edges <- sample(floor(N *l_ratio):floor(N*u_ratio), 1)  # Random number of edges between N/4 and 3N/4
    edges[[as.character(i)]] <- sample(indices, num_edges)  # Randomly sample edges
    indices <- c(indices, i)  # Add i back to indices
  }
  
  return(Network$new(edges, symmetry = FALSE))  # Assuming Network is an R6 class or similar
}

NetworkModel = setRefClass(
  "NetworkModel",
  
  fields = list(
    alpha_order = "numeric",
    alpha_orders = "numeric",
    beta_order = "numeric",
    intercept = "logical",
    global_intercept = "logical",
    network = "Network",
    vts = "matrix"
  ),
  
  methods = list(
    initialize = function(alpha_order,beta_order,intercept,global_intercept){
      .self$beta_order = beta_order
      .self$intercept = intercept
      .self$global_intercept = global_intercept
      if (is.numeric(alpha_order) && length(alpha_order) == 1) {
        .self$alpha_order <- alpha_order
        .self$alpha_orders <- rep(1, alpha_order)
      } else {
        .self$alpha_order <- length(alpha_order)
        .self$alpha_orders <- alpha_order
      }
    },
    
    transformVTS = function(vts){
      X = list()
      for(t in 1:.self$alpha_order){
        vts_temp = vts[(.self$alpha_order-t+1):(nrow(vts)-t),,drop=F]
        w_mats_temp = .self$network$w_mats[(2-.self$alpha_orders[[t]]):(1+.self$beta_order[[t]])]
        temp = matrix(NA, nrow=nrow(vts_temp), ncol=(.self$network$size*length(w_mats_temp)))
        for(i in 1:length(w_mats_temp)){
          temp[,((i-1)*.self$network$size+1):(i*.self$network$size)] = vts_temp%*%w_mats_temp[[i]]
        }
        temp = matrix(temp,ncol=.self$alpha_orders[[t]]+.self$beta_order[[t]])
        X[[t]]=temp
      }
      X = do.call(cbind,X)
      
      if (.self$intercept) {
        if (.self$global_intercept) {
          X = cbind(X, matrix(1, nrow(X), 1))
        } else {
          identity_mat = diag(.self$network$size)
          repeated_identity = matrix(rep(identity_mat,each=nrow(vts)-.self$alpha_order),ncol=.self$network$size)
          X = cbind(X, repeated_identity)
        }
      }
      return(X)
    }
  )
)

# Haar mother function
haar_mother <- function(x) {
  return(ifelse((0 <= x) & (x < 0.5), 1, ifelse((0.5 <= x) & (x < 1), -1, 0)))
}

# Haar basis function
haar_basis <- function(x, n, k, T) {
  basis = apply(x,1,function(xi,n,k,T){
    2^(n / 2) * matrix(haar_mother(2^n * xi / T - k),nrow=1)
  },n=n,k=k,T=T)
  
  if(length(k)==1){
    return(basis)
  }
  else{
    return(t(basis))
  }
}

# Define the DB class using Reference Class in R
DB <- setRefClass(
  "DB",
  fields = list(
    vanishing_moments = "numeric",
    support = "numeric",
    j0 = "numeric",
    a = "numeric",
    b = "numeric",
    T = "numeric",
    T_ceil = "numeric",
    Vs = "list",
    Ws = "list",
    basis = "matrix"
  ),
  methods = list(
    initialize = function(vanishing_moments,T, T_ceil=NaN,j0=NaN) {
      .self$vanishing_moments = vanishing_moments
      .self$support = 2*vanishing_moments
      switch(as.character(.self$vanishing_moments),
             "2" = {
               .self$a = c((1 + sqrt(3)) / (4 * sqrt(2)),(sqrt(3) + 3) / (4 * sqrt(2)), 
                           (3 - sqrt(3)) / (4 * sqrt(2)), (1 - sqrt(3)) / (4 * sqrt(2)))
               .self$b = c((1 - sqrt(3)) / (4 * sqrt(2)), (sqrt(3) - 3) / (4 * sqrt(2)), 
                           (3 + sqrt(3)) / (4 * sqrt(2)), (-1 - sqrt(3)) / (4 * sqrt(2)))},
             "4" = {
               .self$a = c(0.32580343,1.01094572,0.89220014,-0.03957503,-0.26450717,0.0436163,0.0465036,-0.01498699)/sqrt(2)
               .self$b = c(-0.01498699,-0.0465036,0.0436163,0.26450717,-0.03957503,-0.89220014,1.01094572,-0.32580343)/sqrt(2)
             },
             "8" = {
               .self$a = c(0.05441584224308161,0.3128715909144659,0.6756307362980128,0.5853546836548691,-0.015829105256023893,-0.2840155429624281,0.00047248457399797254,0.128747426620186,
                           -0.01736930100202211,-0.04408825393106472,0.013981027917015516,0.008746094047015655,-0.00487035299301066,-0.0003917403729959771,0.0006754494059985568,-0.00011747678400228192)
               .self$b = c(-0.00011747678400228192,-0.0006754494059985568,-0.0003917403729959771,0.00487035299301066,0.008746094047015655,-0.013981027917015516,-0.04408825393106472,
                           0.01736930100202211,0.128747426620186,-0.00047248457399797254,-0.2840155429624281,0.015829105256023893,0.5853546836548691,-0.6756307362980128,0.3128715909144659,-0.05441584224308161)
             }
      )
      
      .self$T = T
      if(is.nan(T_ceil)){
        .self$T_ceil = T
      }
      else{
        .self$T_ceil = T_ceil
      }
      
      if(is.nan(j0)){
        .self$j0 = ceiling(log2(.self$vanishing_moments))
      }
      else{
        .self$j0 = j0
      }
      
      Vs <<- list(diag(.self$T_ceil))
      Ws <<- list()
      
      for (i in 1:(floor(log2(.self$T_ceil)) - .self$j0)) {
        Ws[[i]] <<- generate_next(Vs[[i]], b)
        Vs[[i + 1]] <<- generate_next(Vs[[i]], a)
      }
      
      basis_temp = t(do.call(rbind, c(Ws, list(Vs[[length(Vs)]]))))
      if(.self$T != .self$T_ceil){
        .self$basis = apply(basis_temp,2,function(xi){approx(seq(1,.self$T_ceil),xi,seq(1,.self$T_ceil,length=.self$T))$y})
      }
      else{
        .self$basis = basis_temp
      }
    },
    
    generate_next = function(V, coefs) {
      N <- nrow(V)
      V_exp <- array(0, dim = c(N / 2, .self$T_ceil, .self$support))
      
      for (i in 1:2) {
        V_exp[ , , i] <- V[seq(i, N, 2), ]
      }
      
      for (i in 3:.self$support){
        V_exp[,,i] = rbind(V[seq(i, N, 2), ],V[seq(2-i%%2,i-1,2),])
      }
      
      result <- apply(V_exp,2,function(xi){xi%*%coefs})
      
      return(result)
    }
  )
)

mad <- function(data, axis = NULL) {
  if (is.null(axis)) {
    return(mean(abs(data - mean(data))))
  } else if (axis == 1) {
    return(apply(data, 2, function(col) mean(abs(col - mean(col)))))
  } else if (axis == 2) {
    return(apply(data, 1, function(row) mean(abs(row - mean(row)))))
  }
}

hard_thresh <- function(x, a) {
  return(ifelse(abs(x) > a, x, 0))
}

soft_thresh = function(x,a){
  
  return(ifelse(t(t(abs(x)) > a), sign(x) * t(t(abs(x)) - a), 0))
}


powerOf2 = function(x) {
  if(x<2)
    return(FALSE)
  else
    return(!any(as.logical(intToBits(x) & intToBits(x-1))))
}

TVGNAR = setRefClass(
  "TVGNAR",
  
  contains = "NetworkModel",
  
  fields = list(
    basis_order = "numeric",
    basis_order_min = "numeric",
    tv_intercept = "logical",
    intercept_basis_order = "numeric",
    family = "character",
    T = "numeric",
    N = "numeric",
    y = "numeric",
    X = "matrix",
    basis = "matrix",
    num_father = "numeric",
    X_basis = "matrix",
    intercept_basis = "matrix",
    basis_coefs = "matrix",
    intercept_basis_coefs = "matrix",
    intercept_coefs = "numeric",
    #res = "numeric",
    mad = "numeric",
    thresh_const = "numeric",
    num_coefs = "numeric"
  ),
  
  methods = list(
    initialize = function(alpha_order,beta_order,basis_order=NaN,basis_order_min=NaN,intercept=TRUE,global_intercept=FALSE,tv_intercept=TRUE,family="haar"){
      callSuper(alpha_order,beta_order,intercept,global_intercept)
      .self$basis_order <- basis_order
      .self$basis_order_min <- basis_order_min
      .self$tv_intercept = tv_intercept
      .self$family <- family
      .self$num_coefs <- sum(.self$alpha_orders)+sum(.self$beta_order)
    },
    
    generate_basis_haar = function(){
      t = seq(1,.self$T-.self$alpha_order)
      t[length(t)] = t[length(t)] - 1e-10
      .self$num_father = 1
      basis_list <- lapply(0:.self$basis_order, function(n) {
        # Call the haar_basis_r function for each n
        haar_basis(matrix(t, ncol=1), n, 0:(2^n - 1), .self$T-.self$alpha_order)
      })
      
      return(do.call(cbind, c(list(matrix(1, nrow=length(t), ncol=1)), basis_list)))
    },
    
    generate_basis_db = function(vanishing_moments,basis_order_min){
      db = DB$new(vanishing_moments, T=.self$T-.self$alpha_order, T_ceil=as.integer(2**ceiling(log2(.self$T-.self$alpha_order))), j0=basis_order_min)
      basis_db = db$basis[,ncol(db$basis):(ncol(db$basis)-2**(1+.self$basis_order)+1)]
      .self$basis_order_min = db$j0
      .self$num_father = 2**db$j0
      return(basis_db)
    },
    
    generate_basis = function(){
      if (substring(.self$family,1,2)=="db"){
        return(.self$generate_basis_db(as.integer(substring(.self$family,3,nchar(.self$family))),.self$basis_order_min))
      }
      switch (.self$family,
              haar = return(.self$generate_basis_haar()),
      )
    },
    
    basis_expand = function(A,basis){
      basis_rep = do.call(rbind,replicate(.self$N,basis,simplify = FALSE))
      A_basis = apply(A,2,function(xi,basis_rep){
        xi*basis_rep
      },basis_rep = basis_rep)
      A_basis = matrix(A_basis,nrow = nrow(X))
      return(A_basis)
    },
    
    fit = function(network, vts, thresh="soft", mad_level=1, thresh_const_mult=1, solver="direct"){
      .self$network = network
      .self$vts = vts
      .self$T = nrow(.self$vts)
      .self$N = ncol(.self$vts)
      
      if(is.nan(.self$basis_order)){
        .self$basis_order = floor(log2(sqrt((.self$T-.self$alpha_order)*.self$N)))
        if(.self$intercept){
          if(!.self$global_intercept){
            .self$intercept_basis_order = floor(log2(sqrt(.self$T-.self$alpha_order)))
          }
          else{
            .self$intercept_basis_order = basis_order
          }
        }
      }
      else{
        .self$intercept_basis_order = basis_order
      }
      
      .self$y = c(.self$vts[(.self$alpha_order+1):nrow(.self$vts),])
      .self$X = .self$transformVTS(.self$vts)
      
      .self$basis = .self$generate_basis()
      
      if(.self$intercept){
        if(.self$tv_intercept){
          if(!.self$global_intercept){
            .self$intercept_basis = .self$basis[,1:2**(1+.self$intercept_basis_order)]
            .self$X_basis = do.call(cbind,list(.self$basis_expand(.self$X[,1:(.self$num_coefs)],.self$basis),
                                               .self$basis_expand(.self$X[,(.self$num_coefs+1):ncol(.self$X)],.self$intercept_basis)))
          }
          else{
            .self$X_basis = .self$basis_expand(.self$X,.self$basis)
          }
        }
        else{
          .self$X_basis = do.call(cbind,list(.self$basis_expand(.self$X[,1:.self$num_coefs], .self$basis),
                                             .self$X[,(.self$num_coefs+1):ncol(.self$X)]))
        }
      }
      else{
        .self$X_basis = .self$basis_expand(.self$X,.self$basis)
      }
      
      switch (solver,
              direct = {coefs_vec = least_squares_direct_eig(.self$X_basis, .self$y)},
              qr = {coefs_vec = least_squares_qr_eig(.self$X_basis, .self$y)}
      )
      
      if(!.self$intercept){
        .self$basis_coefs = matrix(coefs_vec,nrow = ncol(.self$basis), ncol = ncol(.self$X))
      }
      else{
        if(.self$tv_intercept){
          if(!.self$global_intercept){
            .self$basis_coefs = matrix(coefs_vec[1:(length(coefs_vec)-ncol(.self$intercept_basis)*.self$N)], nrow = ncol(.self$basis), ncol = .self$num_coefs)
            .self$intercept_basis_coefs = matrix(coefs_vec[(length(coefs_vec)-ncol(.self$intercept_basis)*.self$N+1):length(coefs_vec)], nrow = ncol(.self$intercept_basis), ncol = .self$N)
          }
          else{
            basis_coefs_temp = matrix(coefs_vec, nrow = ncol(.self$basis), ncol = ncol(.self$X))
            .self$basis_coefs = basis_coefs_temp[,1:.self$num_coefs]
            .self$intercept_basis_coefs = matrix(basis_coefs_temp[,(.self$num_coefs+1):ncol(.self$X)],nrow = nrow(basis_coefs_temp))
          }
        }
        else{
          .self$basis_coefs = matrix(coefs_vec[1:(ncol(.self$basis)*.self$num_coefs)],nrow = ncol(.self$basis), ncol = .self$num_coefs)
          .self$intercept_coefs = coefs_vec[(ncol(.self$basis)*.self$num_coefs+1):length(coefs_vec)]
        }
      }
      
      if((.self$family == "haar" || substring(.self$family,1,2)=="db") && !is.null(thresh)){
        .self$wavelet_thresh(thresh,mad_level,thresh_const_mult)
      }
    },
    
    wavelet_thresh = function(thresh,mad_level=1,thresh_const_mult=1){
      num_basis = nrow(.self$basis_coefs)
      index = sum(sapply(0:(mad_level-1), function(n) 2^(.self$basis_order - n)))
      .self$mad = mad(.self$basis_coefs[(num_basis-index+1):num_basis,],axis = 1)
      .self$thresh_const = thresh_const_mult*sqrt(2*log(num_basis-.self$num_father))
      if(thresh == "hard"){
        thresh_fun = hard_thresh
      }
      else if(thresh == "soft"){
        thresh_fun = soft_thresh
      }
      .self$basis_coefs[(.self$num_father+1):num_basis,] = thresh_fun(
        .self$basis_coefs[(.self$num_father+1):num_basis,], .self$mad*.self$thresh_const)
      if(.self$intercept && .self$tv_intercept){
        num_intercept_basis = nrow(.self$intercept_basis_coefs)
        index = sum(sapply(0:(mad_level-1), function(n) 2^(.self$intercept_basis_order - n)))
        .self$intercept_basis_coefs[(.self$num_father+1):num_intercept_basis,] = thresh_fun(
          .self$intercept_basis_coefs[(.self$num_father+1):num_intercept_basis,], 
          mad(.self$intercept_basis_coefs[(num_intercept_basis-index+1):num_intercept_basis,,drop=F],axis = 1)*.self$thresh_const)
      }
    },
    
    get_coefs = function(){
      return(.self$basis%*%.self$basis_coefs)
    },
    
    get_intercept = function(){
      if(.self$intercept){
        if(.self$tv_intercept){
          if(!.self$global_intercept){
            return(.self$intercept_basis%*%.self$intercept_basis_coefs)
          }
          else{
            return(.self$basis%*%.self$intercept_basis_coefs)
          }
        }
        else{
          return(.self$intercept_coefs)
        }
      }
      else{
        return(NaN)
      }
    },
    
    simulate = function(network, initial_vts, length, coefs, Sigma){
      .self$network = network
      l = nrow(initial_vts)
      vts_sim = matrix(0,length+l,.self$network$size)
      vts_sim[1:l,] = initial_vts
      for(i in 1:length){
        vts_sim[l+i,] = .self$transformVTS(vts_sim[(l+i-.self$alpha_order):(l+i),])%*%coefs[i,] + mvrnorm(mu=rep(0,.self$network$size),Sigma = Sigma)
      }
      return(vts_sim[l:length+l,])
    },
    
    show = function(){
      cat("TVGNAR(", as.character(.self$alpha_order), " ,[", 
          do.call(paste, c(as.list(.self$beta_order), sep = ",")),
          "]) model with ", .self$family, " wavelets and ", sep="")
      if(.self$intercept){
        if(.self$global_intercept){
          if(.self$tv_intercept){
            cat("time-varying gloabl intercept.")
          }
          else{
            cat("constant gloabl intercept.")
          }
        }
        else{
          if(.self$tv_intercept){
            cat("time-varying non-gloabl intercept.")
          }
          else{
            cat("constant non-gloabl intercept.")
          }
        }
      }
      else{
        cat("no intercept.")
      }
    }
  )
)

TVGNAR_sim = function(network, alpha_order, beta_order, coefs, intercept, global_intercept, Sigma, length, burn_in=100){
  vts = matrix(0,length+burn_in+alpha_order,network$size)
  vts[1:alpha_order,] = matrix(rnorm(alpha_order*network$size),alpha_order,network$size)
  model = TVGNAR$new(alpha_order, beta_order, basis_order = 1, intercept = intercept, global_intercept = global_intercept)
  vts[(alpha_order+1):(length+burn_in+alpha_order),] = model$simulate(network,vts[1:alpha_order,,drop=FALSE],length+burn_in,coefs,Sigma)
  return(vts[(burn_in+alpha_order+1):(burn_in+alpha_order+length),])
}

